# $Id: mysql.sql 1753 2011-01-26 16:04:51Z jberanek $
