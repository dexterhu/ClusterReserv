# $Id: mysql.sql 1134 2009-06-26 14:08:28Z jberanek $
